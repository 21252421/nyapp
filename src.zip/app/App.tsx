import React, { useState } from 'react';
import { useStore } from './store';
import { Leaderboard } from './components/Leaderboard';
import { Rules } from './components/Rules';
import { DailyEntry } from './components/DailyEntry';
import { TeamManagement } from './components/TeamManagement';
import { DataManagement } from './components/DataManagement';
import { CountdownSettings } from './components/CountdownSettings';
import { 
  LayoutDashboard, 
  ScrollText, 
  PenTool, 
  Users, 
  Database, 
  Settings, 
  LogIn, 
  LogOut,
  Menu,
  X,
  ChevronRight
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { motion, AnimatePresence } from 'motion/react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Tab = 'leaderboard' | 'rules' | 'entry' | 'teams' | 'data' | 'settings';

export default function App() {
  const store = useStore();
  const [activeTab, setActiveTab] = useState<Tab>('leaderboard');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [loginForm, setLoginForm] = useState({ user: '', pass: '' });
  const [showLogin, setShowLogin] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginForm.user === 'Taras' && loginForm.pass === 'Taras8800app') {
      store.setIsLoggedIn(true);
      setShowLogin(false);
      setLoginForm({ user: '', pass: '' });
    } else {
      alert('Forkert brugernavn eller kodeord');
    }
  };

  const navItems = [
    { id: 'leaderboard', label: 'Leaderboard', icon: LayoutDashboard, public: true },
    { id: 'rules', label: 'Regler', icon: ScrollText, public: true },
    { id: 'entry', label: 'Indtastning', icon: PenTool, public: false },
    { id: 'teams', label: 'Holdene', icon: Users, public: false },
    { id: 'data', label: 'Dataoversigt', icon: Database, public: false },
    { id: 'settings', label: 'Indstillinger', icon: Settings, public: false },
  ];

  const filteredNav = navItems.filter(item => item.public || store.isLoggedIn);

  const renderContent = () => {
    switch (activeTab) {
      case 'leaderboard':
        return <Leaderboard 
          teams={store.teams} 
          members={store.members} 
          entries={store.entries} 
          countdownTarget={store.countdownTarget} 
        />;
      case 'rules':
        return <Rules />;
      case 'entry':
        return <DailyEntry 
          members={store.members} 
          teams={store.teams} 
          onAddEntry={store.addEntry} 
        />;
      case 'teams':
        return <TeamManagement 
          teams={store.teams} 
          members={store.members} 
          onAddMember={store.addMember}
          onRemoveMember={store.removeMember}
          onUpdateTeamName={store.updateTeamName}
        />;
      case 'data':
        return <DataManagement 
          entries={store.entries} 
          members={store.members} 
          teams={store.teams} 
          onUpdate={store.updateEntry}
          onDelete={store.deleteEntry}
        />;
      case 'settings':
        return <CountdownSettings 
          current={store.countdownTarget} 
          onUpdate={store.setCountdownTarget} 
        />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-secondary font-sans selection:bg-primary/10">
      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 bg-white border-r border-slate-100 transition-all duration-300 z-50 overflow-hidden shadow-2xl md:shadow-none",
        isMenuOpen ? "w-72 translate-x-0" : "-translate-x-full md:translate-x-0 md:w-72"
      )}>
        <div className="flex flex-col h-full p-6">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-primary rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
                <LayoutDashboard size={24} />
              </div>
              <div className="flex flex-col">
                <h1 className="text-xl font-black text-secondary leading-none">FLAMMENS</h1>
                <p className="text-[10px] font-bold text-primary tracking-widest uppercase">KONKURRENCE</p>
              </div>
            </div>
            <button className="md:hidden text-slate-400" onClick={() => setIsMenuOpen(false)}>
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 space-y-1.5">
            {filteredNav.map(item => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as Tab);
                    setIsMenuOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center justify-between group px-4 py-3.5 rounded-2xl font-bold transition-all duration-300",
                    isActive 
                      ? "bg-primary text-white shadow-xl shadow-primary/20" 
                      : "text-slate-500 hover:text-primary hover:bg-primary/5"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <item.icon size={20} className={cn("transition-colors", isActive ? "text-white" : "group-hover:text-primary")} />
                    <span className="tracking-tight">{item.label}</span>
                  </div>
                  {isActive && <ChevronRight size={16} className="opacity-50" />}
                </button>
              );
            })}
          </nav>
          
          <div className="pt-6 border-t border-slate-50">
            {!store.isLoggedIn ? (
              <button 
                onClick={() => setShowLogin(true)}
                className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl font-bold text-slate-400 hover:text-primary hover:bg-primary/5 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                  <LogIn size={20} />
                </div>
                <span>Admin Login</span>
              </button>
            ) : (
              <button 
                onClick={() => {
                  store.setIsLoggedIn(false);
                  setActiveTab('leaderboard');
                }}
                className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl font-bold text-red-500 hover:bg-red-50 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center group-hover:bg-red-100 transition-colors">
                  <LogOut size={20} />
                </div>
                <span>Log ud</span>
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main Container */}
      <div className="md:ml-72 min-h-screen">
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-100 z-40 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white">
              <LayoutDashboard size={18} />
            </div>
            <span className="font-black text-secondary uppercase tracking-tight">Flammen</span>
          </div>
          <button className="p-2 bg-slate-100 rounded-lg" onClick={() => setIsMenuOpen(true)}>
            <Menu size={20} className="text-secondary" />
          </button>
        </header>

        {/* Dynamic Content */}
        <main className="p-4 md:p-10">
          <div className="max-w-6xl mx-auto space-y-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
              >
                {renderContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Login Modal */}
      <AnimatePresence>
        {showLogin && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogin(false)}
              className="absolute inset-0 bg-secondary/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl border border-white"
            >
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h2 className="text-3xl font-black text-secondary mb-1">Velkommen</h2>
                  <p className="text-slate-400 font-medium">Log ind som admin</p>
                </div>
                <button 
                  onClick={() => setShowLogin(false)} 
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-50 text-slate-400 hover:text-primary transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Brugernavn</label>
                  <input 
                    type="text" 
                    required
                    value={loginForm.user}
                    onChange={e => setLoginForm({...loginForm, user: e.target.value})}
                    className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary outline-none text-secondary font-bold placeholder:text-slate-300 transition-all"
                    placeholder="Dit navn"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Adgangskode</label>
                  <input 
                    type="password" 
                    required
                    value={loginForm.pass}
                    onChange={e => setLoginForm({...loginForm, pass: e.target.value})}
                    className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary outline-none text-secondary font-bold placeholder:text-slate-300 transition-all"
                    placeholder="••••••••"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-primary text-white font-black p-5 rounded-2xl hover:bg-red-700 transition-all shadow-xl shadow-primary/20 flex items-center justify-center gap-3 active:scale-95"
                >
                  <LogIn size={20} />
                  Log ind i systemet
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
