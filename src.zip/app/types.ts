import { format } from 'date-fns';

export interface Member {
  id: string;
  name: string;
  teamId: string;
}

export interface Team {
  id: string;
  name: string;
}

export interface Entry {
  id: string;
  date: string;
  
  // Selection
  udskaererIds: string[]; // Max 2
  opfylderId: string;
  bmId: string;
  opvaskerId: string;
  taId: string;
  
  // Data
  krPrGaest: number;
  salatspild: number;
  forretspild: number;
  pakkefejl: boolean; // true = error, false = no error
  csat: number;
  nps: number;
  gaesteklager: number;
  opvaskFardig: boolean;
  bonus100: boolean;
}

export const CALCULATE_POINTS = (entry: Entry, members: Member[]) => {
  const teamPoints: Record<string, number> = {};

  const addPointsToTeam = (memberId: string, pts: number) => {
    const member = members.find(m => m.id === memberId);
    if (member && pts !== 0) {
      teamPoints[member.teamId] = (teamPoints[member.teamId] || 0) + pts;
    }
  };

  // 1. Udskærer (Kr pr gæst)
  const udskaererPts = entry.krPrGaest < 33 ? 2 : 0;
  entry.udskaererIds.forEach(id => addPointsToTeam(id, udskaererPts));

  // 2. Opfylder (Salat + Forret)
  const salatPts = entry.salatspild < 2.5 ? 2 : 0;
  const forretPts = entry.forretspild < 1.1 ? 2 : 0;
  addPointsToTeam(entry.opfylderId, salatPts + forretPts);

  // 3. TakeAway (Pakkefejl)
  const taPts = !entry.pakkefejl ? 1 : 0;
  addPointsToTeam(entry.taId, taPts);

  // 4. BM (CSAT + NPS + Klager)
  let csatPts = 0;
  if (entry.csat >= 98) csatPts = 3;
  else if (entry.csat >= 96) csatPts = 2;

  let npsPts = 0;
  if (entry.nps >= 75) npsPts = 3;
  else if (entry.nps >= 72) npsPts = 2;

  const klagerPts = entry.gaesteklager * -1;
  addPointsToTeam(entry.bmId, csatPts + npsPts + klagerPts);

  // 5. Opvasker (Færdig til tiden)
  const opvaskPts = entry.opvaskFardig ? 1 : 0;
  addPointsToTeam(entry.opvaskerId, opvaskPts);

  // 6. Bonus 100/100
  if (entry.bonus100) {
    const allWorkingIds = [
      ...entry.udskaererIds,
      entry.opfylderId,
      entry.bmId,
      entry.opvaskerId,
      entry.taId
    ].filter(Boolean);
    
    // Each person working gets +3 for their team
    allWorkingIds.forEach(id => addPointsToTeam(id, 3));
  }

  return teamPoints;
};
