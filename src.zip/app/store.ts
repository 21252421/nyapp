import { useState, useEffect } from 'react';
import { Team, Member, Entry } from './types';

const STORAGE_KEY = 'konkurrence_app_data';

export const useStore = () => {
  const [teams, setTeams] = useState<Team[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_teams`);
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Hold 1' },
      { id: '2', name: 'Hold 2' },
      { id: '3', name: 'Hold 3' },
      { id: '4', name: 'Hold 4' },
    ];
  });

  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_members`);
    return saved ? JSON.parse(saved) : [];
  });

  const [entries, setEntries] = useState<Entry[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_entries`);
    return saved ? JSON.parse(saved) : [];
  });

  const [countdownTarget, setCountdownTarget] = useState<string>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_countdown`);
    return saved || new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0, 23, 59, 59).toISOString();
  });

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_teams`, JSON.stringify(teams));
  }, [teams]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_members`, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_entries`, JSON.stringify(entries));
  }, [entries]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_countdown`, countdownTarget);
  }, [countdownTarget]);

  const addEntry = (entry: Entry) => setEntries(prev => [...prev, entry]);
  const updateEntry = (updated: Entry) => setEntries(prev => prev.map(e => e.id === updated.id ? updated : e));
  const deleteEntry = (id: string) => setEntries(prev => prev.filter(e => e.id !== id));

  const addMember = (m: Member) => setMembers(prev => [...prev, m]);
  const removeMember = (id: string) => setMembers(prev => prev.filter(m => m.id !== id));
  
  const updateTeamName = (id: string, name: string) => {
    setTeams(prev => prev.map(t => t.id === id ? { ...t, name } : t));
  };

  return {
    teams,
    members,
    entries,
    countdownTarget,
    isLoggedIn,
    setIsLoggedIn,
    setCountdownTarget,
    addEntry,
    updateEntry,
    deleteEntry,
    addMember,
    removeMember,
    updateTeamName,
  };
};
