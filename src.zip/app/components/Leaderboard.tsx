import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Clock, Target, Users as UsersIcon } from 'lucide-react';
import { Team, Member, Entry, CALCULATE_POINTS } from '../types';
import { differenceInDays, differenceInHours, differenceInMinutes, differenceInSeconds } from 'date-fns';
import { motion } from 'motion/react';

interface LeaderboardProps {
  teams: Team[];
  members: Member[];
  entries: Entry[];
  countdownTarget: string;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ teams, members, entries, countdownTarget }) => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const target = new Date(countdownTarget);
      
      if (target > now) {
        setTimeLeft({
          days: Math.max(0, differenceInDays(target, now)),
          hours: Math.max(0, differenceInHours(target, now) % 24),
          minutes: Math.max(0, differenceInMinutes(target, now) % 60),
          seconds: Math.max(0, differenceInSeconds(target, now) % 60)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [countdownTarget]);

  const teamStats = teams.map(team => {
    let totalPoints = 0;
    entries.forEach(entry => {
      const ptsMap = CALCULATE_POINTS(entry, members);
      totalPoints += ptsMap[team.id] || 0;
    });
    return {
      ...team,
      totalPoints,
      members: members.filter(m => m.teamId === team.id)
    };
  }).sort((a, b) => b.totalPoints - a.totalPoints);

  const getRankTheme = (index: number) => {
    switch (index) {
      case 0: return { bg: 'bg-white', border: 'border-primary shadow-primary/10', text: 'text-secondary', badge: 'bg-primary text-white' }; 
      case 1: return { bg: 'bg-white', border: 'border-slate-200 shadow-slate-100', text: 'text-slate-800', badge: 'bg-slate-500 text-white' };  
      case 2: return { bg: 'bg-white', border: 'border-slate-200 shadow-slate-100', text: 'text-slate-700', badge: 'bg-amber-600 text-white' }; 
      default: return { bg: 'bg-white', border: 'border-slate-100 shadow-slate-50', text: 'text-slate-600', badge: 'bg-slate-300 text-white' };      
    }
  };

  const getMedal = (index: number) => {
    switch (index) {
      case 0: return <div className="p-3 bg-amber-400 rounded-2xl shadow-lg shadow-amber-400/20"><Trophy className="text-secondary w-6 h-6" /></div>;
      case 1: return <div className="p-3 bg-slate-300 rounded-2xl shadow-lg shadow-slate-100"><Medal className="text-white w-6 h-6" /></div>;
      case 2: return <div className="p-3 bg-amber-700 rounded-2xl shadow-lg shadow-amber-700/20"><Medal className="text-white w-6 h-6" /></div>;
      default: return <div className="p-3 bg-slate-100 rounded-2xl"><Target className="text-slate-400 w-6 h-6" /></div>;
    }
  };

  return (
    <div className="space-y-10">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row gap-6 items-stretch">
        <div className="flex-1 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col justify-center">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center text-primary">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">Tid tilbage</p>
              <h2 className="text-secondary font-black">Konkurrence slutter om</h2>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[
              { val: timeLeft.days, label: 'Dage' },
              { val: timeLeft.hours, label: 'Timer' },
              { val: timeLeft.minutes, label: 'Minutter' },
              { val: timeLeft.seconds, label: 'Sekunder' }
            ].map((t, i) => (
              <div key={i} className="bg-slate-50 rounded-2xl p-4 text-center">
                <div className="text-3xl font-black text-secondary leading-none mb-1">{t.val.toString().padStart(2, '0')}</div>
                <div className="text-[10px] font-black text-slate-300 uppercase tracking-tighter">{t.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-primary p-8 rounded-[2.5rem] text-white shadow-xl shadow-primary/20 flex flex-col justify-center min-w-[300px]">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
              <Trophy size={24} />
            </div>
            <div>
              <p className="text-white/70 font-bold uppercase text-[10px] tracking-widest">Nuværende leder</p>
              <h2 className="text-white font-black truncate">{teamStats[0]?.name || 'Ingen data'}</h2>
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-5xl font-black">{teamStats[0]?.totalPoints || 0}</span>
            <span className="text-white/70 font-black uppercase text-sm">Points totalt</span>
          </div>
        </div>
      </div>

      {/* Leaderboard List */}
      <div className="grid gap-6">
        <div className="flex items-center justify-between px-4">
          <h3 className="text-xl font-black text-secondary flex items-center gap-3">
            <div className="w-2 h-8 bg-primary rounded-full" />
            Top Hold
          </h3>
          <div className="flex items-center gap-2 text-slate-400 font-bold text-sm">
            <UsersIcon size={16} />
            {members.length} Medarbejdere
          </div>
        </div>

        {teamStats.map((team, index) => {
          const theme = getRankTheme(index);
          const pointsTarget = 500;
          const progress = Math.min(100, (team.totalPoints / pointsTarget) * 100);

          return (
            <motion.div 
              key={team.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`group p-8 rounded-[2.5rem] border-2 transition-all hover:scale-[1.01] hover:shadow-2xl ${theme.bg} ${theme.border} ${index === 0 ? 'shadow-2xl' : 'shadow-sm'}`}
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="flex items-center gap-6">
                  <div className="relative">
                    {getMedal(index)}
                    <div className={`absolute -top-2 -right-2 w-7 h-7 ${theme.badge} rounded-full flex items-center justify-center text-[10px] font-black shadow-lg`}>
                      {index + 1}
                    </div>
                  </div>
                  <div>
                    <h3 className={`text-2xl font-black ${theme.text} mb-2 tracking-tight`}>{team.name}</h3>
                    <div className="flex flex-wrap gap-1.5">
                      {team.members.map(m => (
                        <span key={m.id} className="text-[10px] font-black uppercase tracking-widest px-3 py-1 bg-slate-50 text-slate-400 rounded-full group-hover:bg-primary/5 group-hover:text-primary transition-colors">
                          {m.name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex md:flex-col items-center md:items-end justify-between w-full md:w-auto gap-2">
                  <div className={`text-5xl font-black ${theme.text} tracking-tighter`}>{team.totalPoints}</div>
                  <div className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Points i alt</div>
                </div>
              </div>
              
              <div className="mt-8 space-y-3">
                <div className="flex justify-between items-end text-[10px] font-black uppercase tracking-widest">
                  <span className="text-slate-400">Fremskridt mod mål</span>
                  <span className="text-primary">{Math.round(progress)}%</span>
                </div>
                <div className="h-4 w-full bg-slate-50 rounded-full overflow-hidden p-1 border border-slate-100">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 1, ease: "easeOut", delay: 0.5 + (index * 0.1) }}
                    className={`h-full rounded-full ${index === 0 ? 'bg-primary' : 'bg-slate-400'} shadow-sm`}
                  />
                </div>
                <div className="flex justify-between mt-1 text-[8px] font-bold text-slate-300 uppercase tracking-[0.2em]">
                  <span>Sæson start</span>
                  <span>Mål: {pointsTarget} pts</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
