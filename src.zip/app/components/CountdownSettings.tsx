import React, { useState } from 'react';
import { Calendar, RefreshCw, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { motion } from 'motion/react';

interface CountdownSettingsProps {
  current: string;
  onUpdate: (iso: string) => void;
}

export const CountdownSettings: React.FC<CountdownSettingsProps> = ({ current, onUpdate }) => {
  const [date, setDate] = useState(format(new Date(current), "yyyy-MM-dd"));
  const [time, setTime] = useState(format(new Date(current), "HH:mm"));

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const iso = new Date(`${date}T${time}`).toISOString();
    onUpdate(iso);
    alert('Deadline opdateret!');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center space-y-2 mb-10">
        <h2 className="text-4xl font-black text-secondary tracking-tight">Indstillinger</h2>
        <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.3em]">Sæt rammerne for konkurrencen</p>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-12 rounded-[3rem] shadow-sm border border-slate-100"
      >
        <div className="flex items-center gap-4 mb-10 justify-center">
          <div className="w-14 h-14 bg-primary/5 rounded-2xl flex items-center justify-center text-primary shadow-inner">
            <Clock size={28} />
          </div>
          <div className="text-left">
            <h3 className="text-2xl font-black text-secondary leading-none">Deadline</h3>
            <p className="text-slate-400 text-xs font-bold mt-1">Hvornår skal point tælles op?</p>
          </div>
        </div>
        
        <form onSubmit={handleSave} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Slutdato</label>
              <input 
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full p-5 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-black outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Sluttidspunkt</label>
              <input 
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full p-5 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-black outline-none transition-all"
              />
            </div>
          </div>
          
          <button 
            type="submit"
            className="w-full bg-secondary text-white font-black p-6 rounded-2xl hover:bg-stone-800 transition-all flex items-center justify-center gap-3 mt-4 shadow-2xl shadow-secondary/10 active:scale-95"
          >
            <RefreshCw className="w-5 h-5" />
            Opdater deadline nu
          </button>
        </form>

        <div className="mt-12 p-8 bg-primary/5 rounded-[2rem] border border-primary/10 flex items-center gap-6">
          <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-primary shadow-sm shrink-0">
            <Calendar size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-primary/60 uppercase tracking-widest mb-1">Aktiv deadline</p>
            <p className="text-secondary font-black text-lg">
              {format(new Date(current), 'eeee d. MMMM yyyy - HH:mm')}
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
