import React from 'react';
import { Target, Info, Star, ChevronRight, Calculator, Award } from 'lucide-react';
import { motion } from 'motion/react';

export const Rules: React.FC = () => {
  return (
    <div className="space-y-12 max-w-5xl mx-auto">
      <div className="text-center space-y-2">
        <h2 className="text-5xl font-black text-secondary tracking-tight">Konkurrence Regler</h2>
        <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.3em]">Sådan optjener jeres hold points</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Point Breakdown */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm space-y-8"
        >
          <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
            <div className="w-14 h-14 bg-primary/5 rounded-2xl flex items-center justify-center text-primary">
              <Calculator size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-secondary leading-none">Standard Point</h3>
              <p className="text-slate-400 text-xs font-bold mt-1">Daglige mål og belønninger</p>
            </div>
          </div>

          <div className="space-y-6">
            <RuleItem label="Kr. pr gæst - under 33kr" pts="2 pts" />
            <RuleItem label="Salatspild - under 2.5kg" pts="2 pts" />
            <RuleItem label="Forretspild - under 1.1kg" pts="2 pts" />
            <RuleItem label="Ingen Pakkefejl (TA)" pts="1 pt" />
            <RuleItem label="Opvasker færdig til tiden" pts="1 pt" />
            
            <div className="pt-4 space-y-4">
              <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Service & Kvalitet</h4>
              <RuleItem label="CSAT 98+" pts="3 pts" />
              <RuleItem label="CSAT 96-97" pts="2 pts" />
              <RuleItem label="NPS 75+" pts="3 pts" />
              <RuleItem label="NPS 72-74" pts="2 pts" />
              <RuleItem label="Gæsteklage (Køkken)" pts="-1 pt" color="text-red-500" />
            </div>
          </div>
        </motion.div>

        {/* Bonus & Logic */}
        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-secondary p-10 rounded-[3rem] text-white shadow-2xl shadow-secondary/10 relative overflow-hidden"
          >
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center text-accent shadow-inner">
                  <Star size={28} fill="currentColor" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white leading-none">Super Bonus 100/100</h3>
                  <p className="text-slate-300 text-xs font-bold mt-1">Den ultimative præstation</p>
                </div>
              </div>
              <p className="text-slate-300 font-medium leading-relaxed mb-6">
                Hvis både <span className="text-white font-black">CSAT</span> og <span className="text-white font-black">NPS</span> er præcis <span className="text-accent font-black">100</span>, 
                modtager <span className="text-white font-bold italic">alle</span> medarbejdere på vagt den dag:
              </p>
              <div className="flex items-center gap-3 bg-white/5 p-6 rounded-2xl border border-white/10">
                <Award className="text-accent w-8 h-8 shrink-0" />
                <span className="text-3xl font-black text-white">+3 bonus point</span>
                <span className="text-slate-500 text-[10px] uppercase font-bold ml-auto">pr. person</span>
              </div>
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary/20 blur-[60px] rounded-full" />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm"
          >
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 shrink-0">
                <Info size={20} />
              </div>
              <div className="space-y-4">
                <h4 className="text-lg font-black text-secondary uppercase tracking-tight">Vigtig Information</h4>
                <p className="text-slate-500 text-sm leading-relaxed font-medium">
                  Systemet tildeler automatisk point til medarbejderens hold baseret på de indtastede data. 
                  Hvis flere medarbejdere har samme stilling, modtager begge point til deres respektive hold.
                </p>
                <div className="flex items-center gap-2 text-primary font-black text-[10px] uppercase tracking-widest">
                  <ChevronRight size={14} />
                  Automatisk pointberegning hver dag
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

const RuleItem = ({ label, pts, color = "text-primary" }: { label: string, pts: string, color?: string }) => (
  <div className="flex justify-between items-center group">
    <span className="text-slate-600 font-bold tracking-tight group-hover:text-secondary transition-colors">{label}</span>
    <span className={`px-4 py-2 rounded-xl bg-slate-50 font-black text-xs uppercase tracking-widest ${color} min-w-[70px] text-center shadow-sm`}>
      {pts}
    </span>
  </div>
);
