import React, { useState } from 'react';
import { Save, Info, UserCheck, Activity, CalendarCheck } from 'lucide-react';
import { Member, Team, Entry } from '../types';
import { format } from 'date-fns';
import { motion } from 'motion/react';

interface DailyEntryProps {
  members: Member[];
  teams: Team[];
  onAddEntry: (e: Entry) => void;
  isEditing?: boolean;
  initialData?: Entry | null;
}

export const DailyEntry: React.FC<DailyEntryProps> = ({ members, teams, onAddEntry, isEditing, initialData }) => {
  const [formData, setFormData] = useState<Entry>(initialData || {
    id: crypto.randomUUID(),
    date: format(new Date(), 'yyyy-MM-dd'),
    udskaererIds: [],
    opfylderId: '',
    bmId: '',
    opvaskerId: '',
    taId: '',
    krPrGaest: 0,
    salatspild: 0,
    forretspild: 0,
    pakkefejl: false,
    csat: 0,
    nps: 0,
    gaesteklager: 0,
    opvaskFardig: true,
    bonus100: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddEntry({
      ...formData,
      id: isEditing ? formData.id : crypto.randomUUID(),
      bonus100: formData.csat === 100 && formData.nps === 100
    });
    if (!isEditing) {
      alert('Data gemt!');
    }
  };

  const memberOptions = (
    <>
      <option value="">Vælg person...</option>
      {members.map(m => (
        <option key={m.id} value={m.id}>
          {m.name} ({teams.find(t => t.id === m.teamId)?.name})
        </option>
      ))}
    </>
  );

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-4xl font-black text-secondary mb-1">{isEditing ? 'Rediger' : 'Indtastning'}</h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest ml-1">Daglig Performance Tracking</p>
        </div>
        <div className="bg-white px-6 py-3 rounded-2xl border border-slate-100 shadow-sm">
          <input 
            type="date"
            value={formData.date}
            onChange={e => setFormData({...formData, date: e.target.value})}
            className="bg-transparent border-none text-primary font-black focus:ring-0 cursor-pointer outline-none"
          />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 pb-20">
        {/* Bemandingen Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm"
        >
          <div className="flex items-center gap-4 mb-10">
            <div className="w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center text-primary">
              <UserCheck size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-secondary leading-none">Bemandingen</h3>
              <p className="text-slate-400 text-xs font-bold mt-1">Hvem er på arbejde i dag?</p>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Udskærere (Maks 2)</label>
              <div className="grid grid-cols-2 gap-3">
                <select 
                  value={formData.udskaererIds[0] || ''} 
                  onChange={e => {
                    const newIds = [...formData.udskaererIds];
                    newIds[0] = e.target.value;
                    setFormData({...formData, udskaererIds: newIds.filter(Boolean)});
                  }}
                  className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-bold appearance-none transition-all"
                >
                  {memberOptions}
                </select>
                <select 
                  value={formData.udskaererIds[1] || ''} 
                  onChange={e => {
                    const newIds = [...formData.udskaererIds];
                    newIds[1] = e.target.value;
                    setFormData({...formData, udskaererIds: newIds.filter(Boolean)});
                  }}
                  className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-bold appearance-none transition-all"
                >
                  {memberOptions}
                </select>
              </div>
            </div>

            {[
              { label: 'Opfylder (Salat & Forret)', key: 'opfylderId' },
              { label: 'BM (CSAT, NPS, Klager)', key: 'bmId' },
              { label: 'Opvasker', key: 'opvaskerId' },
              { label: 'TakeAway', key: 'taId' },
            ].map(field => (
              <div key={field.key} className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{field.label}</label>
                <select 
                  value={(formData as any)[field.key]} 
                  onChange={e => setFormData({...formData, [field.key]: e.target.value})}
                  className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-bold appearance-none transition-all"
                >
                  {memberOptions}
                </select>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Performance Data Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm"
        >
          <div className="flex items-center gap-4 mb-10">
            <div className="w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center text-primary">
              <Activity size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-secondary leading-none">Præstation</h3>
              <p className="text-slate-400 text-xs font-bold mt-1">Nøgletal fra dagens drift</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { label: 'Kr. pr gæst', key: 'krPrGaest', step: '0.01' },
              { label: 'Salatspild (kg)', key: 'salatspild', step: '0.1' },
              { label: 'Forretspild (kg)', key: 'forretspild', step: '0.1' },
              { label: 'CSAT', key: 'csat', step: '1' },
              { label: 'NPS', key: 'nps', step: '1' },
              { label: 'Gæsteklager', key: 'gaesteklager', step: '1' },
            ].map(f => (
              <div key={f.key} className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{f.label}</label>
                <input 
                  type="number"
                  step={f.step}
                  value={(formData as any)[f.key]}
                  onChange={e => setFormData({...formData, [f.key]: parseFloat(e.target.value) || 0})}
                  className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-bold transition-all"
                />
              </div>
            ))}
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Pakkefejl?</label>
              <select 
                value={formData.pakkefejl ? 'Ja' : 'Nej'}
                onChange={e => setFormData({...formData, pakkefejl: e.target.value === 'Ja'})}
                className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-bold appearance-none transition-all"
              >
                <option value="Nej">Nej (1 pt)</option>
                <option value="Ja">Ja (0 pts)</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Færdig til tiden?</label>
              <select 
                value={formData.opvaskFardig ? 'Ja' : 'Nej'}
                onChange={e => setFormData({...formData, opvaskFardig: e.target.value === 'Ja'})}
                className="w-full p-4 rounded-2xl bg-slate-50 border-none ring-1 ring-slate-100 focus:ring-2 focus:ring-primary text-secondary font-bold appearance-none transition-all"
              >
                <option value="Ja">Ja (1 pt)</option>
                <option value="Nej">Nej (0 pts)</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Action Button */}
        <div className="flex flex-col md:flex-row gap-6 items-center justify-between bg-secondary p-8 rounded-[2.5rem] shadow-2xl shadow-secondary/10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-accent">
              <Info size={24} />
            </div>
            <p className="text-slate-300 text-sm font-medium max-w-xs">
              Bonus 100/100 aktiveres automatisk hvis CSAT og NPS er 100.
            </p>
          </div>
          <button 
            type="submit"
            className="w-full md:w-auto bg-primary text-white font-black px-12 py-5 rounded-2xl hover:bg-red-700 transition-all flex items-center justify-center gap-3 active:scale-95 shadow-xl shadow-primary/20"
          >
            <CalendarCheck size={24} />
            {isEditing ? 'Opdater data' : 'Gem dagens data'}
          </button>
        </div>
      </form>
    </div>
  );
};
