import React, { useState } from 'react';
import { Table as TableIcon, Edit, Trash2, X, Check, Calendar, ArrowUpDown } from 'lucide-react';
import { Entry, Member, Team } from '../types';
import { DailyEntry } from './DailyEntry';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface DataManagementProps {
  entries: Entry[];
  members: Member[];
  teams: Team[];
  onUpdate: (e: Entry) => void;
  onDelete: (id: string) => void;
}

export const DataManagement: React.FC<DataManagementProps> = ({ entries, members, teams, onUpdate, onDelete }) => {
  const [editingEntry, setEditingEntry] = useState<Entry | null>(null);

  const sortedEntries = [...entries].sort((a, b) => b.date.localeCompare(a.date));

  if (editingEntry) {
    return (
      <div className="space-y-6">
        <button 
          onClick={() => setEditingEntry(null)}
          className="flex items-center gap-2 text-slate-400 font-black uppercase text-xs hover:text-primary transition-colors mb-6 group"
        >
          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center group-hover:bg-primary/10 group-hover:text-primary">
            <X className="w-4 h-4" />
          </div>
          Annuller redigering
        </button>
        <DailyEntry 
          members={members}
          teams={teams}
          isEditing
          initialData={editingEntry}
          onAddEntry={(updated) => {
            onUpdate(updated);
            setEditingEntry(null);
          }}
        />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black text-secondary mb-1">Datahistorik</h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest ml-1">Oversigt over alle indsendte data</p>
        </div>
        <div className="bg-white px-6 py-3 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3">
          <TableIcon className="text-primary w-5 h-5" />
          <span className="text-secondary font-black">{entries.length} indlæg i alt</span>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
                <th className="p-6 border-b border-slate-50">
                  <div className="flex items-center gap-2">
                    Dato <ArrowUpDown size={12} className="opacity-30" />
                  </div>
                </th>
                <th className="p-6 border-b border-slate-50">Kr/Gæst</th>
                <th className="p-6 border-b border-slate-50">Spild (S/F)</th>
                <th className="p-6 border-b border-slate-50">CSAT / NPS</th>
                <th className="p-6 border-b border-slate-50">Status</th>
                <th className="p-6 border-b border-slate-50">Bonus</th>
                <th className="p-6 border-b border-slate-50 text-right">Handlinger</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {sortedEntries.map((entry, idx) => (
                <motion.tr 
                  key={entry.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="group hover:bg-primary/5 transition-colors"
                >
                  <td className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                        <Calendar size={18} />
                      </div>
                      <span className="text-secondary font-black">{format(new Date(entry.date), 'dd/MM/yyyy')}</span>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg font-bold text-xs">{entry.krPrGaest} kr.</span>
                  </td>
                  <td className="p-6">
                    <div className="text-xs font-bold text-slate-500">
                      <span className="text-primary">{entry.salatspild}kg</span> / {entry.forretspild}kg
                    </div>
                  </td>
                  <td className="p-6 font-black text-secondary">
                    <span className={entry.csat >= 98 ? 'text-primary' : 'text-slate-400'}>{entry.csat}</span> 
                    <span className="text-slate-300 mx-2">/</span>
                    <span className={entry.nps >= 75 ? 'text-primary' : 'text-slate-400'}>{entry.nps}</span>
                  </td>
                  <td className="p-6">
                    <div className="flex gap-1.5">
                      <StatusBadge active={!entry.pakkefejl} label="TA" />
                      <StatusBadge active={entry.opvaskFardig} label="Opv" />
                    </div>
                  </td>
                  <td className="p-6">
                    {entry.bonus100 ? (
                      <div className="inline-flex items-center gap-1.5 bg-accent text-secondary px-3 py-1 rounded-full text-[10px] font-black shadow-lg shadow-accent/20">
                        <div className="w-1.5 h-1.5 bg-secondary rounded-full animate-pulse" />
                        SUPER
                      </div>
                    ) : (
                      <span className="text-slate-200 text-xs font-bold">-</span>
                    )}
                  </td>
                  <td className="p-6 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => setEditingEntry(entry)}
                        className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-slate-100 text-slate-400 hover:text-primary hover:border-primary/20 hover:shadow-lg transition-all"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => {
                          if(confirm('Er du sikker på at du vil slette denne indtastning?')) {
                            onDelete(entry.id);
                          }
                        }}
                        className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-slate-100 text-slate-400 hover:text-red-500 hover:border-red-200 hover:shadow-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
              {entries.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 bg-slate-50 rounded-3xl flex items-center justify-center text-slate-200">
                        <TableIcon size={32} />
                      </div>
                      <p className="text-slate-400 font-bold">Ingen data indsendt endnu.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const StatusBadge = ({ active, label }: { active: boolean, label: string }) => (
  <div className={cn(
    "px-2 py-0.5 rounded font-black text-[8px] tracking-tighter uppercase border",
    active ? "bg-primary/5 border-primary/20 text-primary" : "bg-red-50 border-red-100 text-red-400 opacity-50"
  )}>
    {label}
  </div>
);
