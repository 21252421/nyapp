import React, { useState } from 'react';
import { Users, UserPlus, Trash2, Edit2, User, ShieldCheck } from 'lucide-react';
import { Team, Member } from '../types';
import { motion } from 'motion/react';

interface TeamManagementProps {
  teams: Team[];
  members: Member[];
  onAddMember: (m: Member) => void;
  onRemoveMember: (id: string) => void;
  onUpdateTeamName: (id: string, name: string) => void;
}

export const TeamManagement: React.FC<TeamManagementProps> = ({ 
  teams, members, onAddMember, onRemoveMember, onUpdateTeamName 
}) => {
  const [newName, setNewName] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState(teams[0]?.id || '');

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !selectedTeamId) return;
    
    onAddMember({
      id: crypto.randomUUID(),
      name: newName,
      teamId: selectedTeamId
    });
    setNewName('');
  };

  return (
    <div className="space-y-12 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black text-secondary mb-1">Holdene</h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest ml-1">Administrer deltagere og holdnavne</p>
        </div>
        <div className="bg-white px-6 py-3 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3">
          <ShieldCheck className="text-primary w-5 h-5" />
          <span className="text-secondary font-black">Admin Mode</span>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-secondary p-10 rounded-[3rem] shadow-2xl shadow-secondary/10"
      >
        <form onSubmit={handleAddMember} className="grid md:grid-cols-12 gap-6 items-end">
          <div className="md:col-span-5 space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Navn på medarbejder</label>
            <input 
              type="text"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              placeholder="F.eks. Anders Andersen"
              className="w-full p-4 rounded-2xl bg-white/5 border-none ring-1 ring-white/10 focus:ring-2 focus:ring-primary text-white font-bold outline-none placeholder:text-slate-600 transition-all"
            />
          </div>
          <div className="md:col-span-4 space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Tilknyt til hold</label>
            <select 
              value={selectedTeamId}
              onChange={e => setSelectedTeamId(e.target.value)}
              className="w-full p-4 rounded-2xl bg-white/5 border-none ring-1 ring-white/10 focus:ring-2 focus:ring-primary text-white font-bold outline-none appearance-none transition-all"
            >
              {teams.map(t => (
                <option key={t.id} value={t.id} className="bg-secondary text-white">{t.name}</option>
              ))}
            </select>
          </div>
          <div className="md:col-span-3">
            <button 
              type="submit"
              className="w-full bg-primary text-white font-black p-4 rounded-2xl hover:bg-red-700 transition-all flex items-center justify-center gap-3 shadow-xl shadow-primary/20 active:scale-95"
            >
              <UserPlus size={20} />
              Tilføj nu
            </button>
          </div>
        </form>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        {teams.map((team, idx) => (
          <motion.div 
            key={team.id} 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-slate-100 transition-all"
          >
            <div className="flex justify-between items-center mb-8 border-b border-slate-50 pb-6">
              <div className="flex items-center gap-3 group">
                <input 
                  type="text"
                  value={team.name}
                  onChange={e => onUpdateTeamName(team.id, e.target.value)}
                  className="bg-transparent border-none text-2xl font-black text-secondary focus:ring-0 w-full outline-none"
                />
                <Edit2 className="w-4 h-4 text-slate-200 group-hover:text-primary transition-colors" />
              </div>
              <div className="px-4 py-1.5 bg-primary/5 rounded-full text-[10px] font-black text-primary uppercase tracking-widest">
                {members.filter(m => m.teamId === team.id).length} medlemmer
              </div>
            </div>
            
            <div className="grid gap-3">
              {members.filter(m => m.teamId === team.id).map(member => (
                <div key={member.id} className="flex justify-between items-center bg-slate-50/50 p-4 rounded-2xl border border-transparent hover:border-primary/10 hover:bg-white transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-slate-400 group-hover:text-primary shadow-sm transition-colors">
                      <User size={14} />
                    </div>
                    <span className="text-secondary font-bold tracking-tight">{member.name}</span>
                  </div>
                  <button 
                    onClick={() => onRemoveMember(member.id)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-200 hover:text-red-500 hover:bg-red-50 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {members.filter(m => m.teamId === team.id).length === 0 && (
                <p className="text-slate-300 text-xs font-bold text-center py-4 uppercase tracking-widest">Holdet er tomt</p>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
